<?php
session_start();
if (!isset($_SESSION['user_id'])) { header('Location: login.php'); exit; }
require_once 'koneksi.php';

$msg = '';
// Tambah pelanggan
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['aksi'])) {
    if ($_POST['aksi'] === 'tambah') {
        $nama = trim($_POST['nama']);
        $no_hp = trim($_POST['no_hp']);
        $email = trim($_POST['email']) ?: null;
        $tgl = $_POST['tgl_daftar'];
        $saldo = floatval($_POST['saldo']);
        $stmt = $conn->prepare("INSERT INTO pelanggan (nama, no_hp, email, tgl_daftar, saldo) VALUES (?,?,?,?,?)");
        $stmt->bind_param('ssssd', $nama, $no_hp, $email, $tgl, $saldo);
        if ($stmt->execute()) $msg = '<div class="alert-ok">✅ Pelanggan berhasil ditambahkan!</div>';
        else $msg = '<div class="alert-err">❌ Gagal: ' . $conn->error . '</div>';
    } elseif ($_POST['aksi'] === 'hapus') {
        $id = intval($_POST['id']);
        $conn->query("DELETE FROM pelanggan WHERE pelanggan_id = $id");
        $msg = '<div class="alert-ok">✅ Pelanggan dihapus.</div>';
    }
}

$data = $conn->query("SELECT * FROM pelanggan ORDER BY pelanggan_id DESC");
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<title>Pelanggan - Rental Warnet</title>
<style>
  * { box-sizing: border-box; margin: 0; padding: 0; }
  body { font-family: 'Segoe UI', sans-serif; background: #0f0f23; color: #e0e0e0; }
  .sidebar { position: fixed; top: 0; left: 0; width: 240px; height: 100vh; background: #1a1a2e; border-right: 1px solid #2a2a4a; display: flex; flex-direction: column; }
  .sidebar-logo { padding: 20px; border-bottom: 1px solid #2a2a4a; font-size: 18px; font-weight: 700; color: #e94560; }
  .nav-item { display: flex; align-items: center; padding: 10px 20px; color: #aaa; text-decoration: none; font-size: 14px; transition: all 0.2s; }
  .nav-item:hover, .nav-item.active { background: #e9456015; color: #e94560; border-right: 3px solid #e94560; }
  .nav-item .icon { margin-right: 10px; }
  .nav-label { padding: 8px 20px; font-size: 10px; color: #555; text-transform: uppercase; letter-spacing: 1px; }
  .sidebar-footer { margin-top: auto; padding: 15px 20px; border-top: 1px solid #2a2a4a; font-size: 12px; color: #666; }
  .main { margin-left: 240px; padding: 25px; }
  .topbar { display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px; }
  .topbar h1 { font-size: 22px; color: #fff; }
  .card { background: #1a1a2e; border: 1px solid #2a2a4a; border-radius: 12px; padding: 20px; margin-bottom: 20px; }
  .card-title { font-size: 15px; font-weight: 600; color: #fff; margin-bottom: 16px; padding-bottom: 12px; border-bottom: 1px solid #2a2a4a; }
  table { width: 100%; border-collapse: collapse; font-size: 13px; }
  th { padding: 10px 12px; text-align: left; color: #888; border-bottom: 1px solid #2a2a4a; }
  td { padding: 10px 12px; border-bottom: 1px solid #1e1e38; color: #ccc; }
  tr:hover td { background: #ffffff05; }
  .form-row { display: grid; grid-template-columns: repeat(3,1fr); gap: 12px; margin-bottom: 12px; }
  .form-group label { display: block; font-size: 12px; color: #888; margin-bottom: 5px; }
  .form-group input { width: 100%; padding: 10px; background: #0f0f23; border: 1px solid #2a2a4a; border-radius: 8px; color: #fff; font-size: 13px; }
  .form-group input:focus { outline: none; border-color: #e94560; }
  .btn { padding: 10px 20px; border-radius: 8px; font-size: 13px; font-weight: 500; cursor: pointer; border: none; }
  .btn-primary { background: #e94560; color: #fff; }
  .btn-danger  { background: #c0392b; color: #fff; padding: 5px 10px; font-size: 12px; }
  .btn:hover { opacity: 0.85; }
  .alert-ok  { background: #06d6a020; border: 1px solid #06d6a0; color: #06d6a0; padding: 10px 15px; border-radius: 8px; margin-bottom: 15px; }
  .alert-err { background: #e9456020; border: 1px solid #e94560; color: #e94560; padding: 10px 15px; border-radius: 8px; margin-bottom: 15px; }
</style>
</head>
<body>
<div class="sidebar">
  <div class="sidebar-logo">🖥️ Rental Warnet</div>
  <div class="nav-label">Menu Utama</div>
  <a href="dashboard.php" class="nav-item"><span class="icon">📊</span>Dashboard</a>
  <a href="pelanggan.php" class="nav-item active"><span class="icon">👥</span>Pelanggan</a>
  <a href="komputer.php"  class="nav-item"><span class="icon">💻</span>Komputer</a>
  <a href="transaksi.php" class="nav-item"><span class="icon">💳</span>Transaksi</a>
  <a href="sesi.php"      class="nav-item"><span class="icon">⏱️</span>Sesi Aktif</a>
  <?php if ($_SESSION['role'] === 'admin'): ?>
  <div class="nav-label">Admin</div>
  <a href="users.php"  class="nav-item"><span class="icon">🔐</span>Manajemen User</a>
  <a href="backup.php" class="nav-item"><span class="icon">💾</span>Backup & Restore</a>
  <?php endif; ?>
  <div class="sidebar-footer">
    <?= ucfirst($_SESSION['role']) ?> &nbsp;|&nbsp; <a href="logout.php" style="color:#e94560;text-decoration:none">Logout</a>
  </div>
</div>
<div class="main">
  <div class="topbar"><h1>👥 Data Pelanggan</h1></div>
  <?= $msg ?>

  <div class="card">
    <div class="card-title">➕ Tambah Pelanggan</div>
    <form method="POST">
      <input type="hidden" name="aksi" value="tambah">
      <div class="form-row">
        <div class="form-group"><label>Nama Lengkap *</label><input name="nama" required placeholder="Nama pelanggan"></div>
        <div class="form-group"><label>No. HP *</label><input name="no_hp" required placeholder="08xxxxxxxxxx"></div>
        <div class="form-group"><label>Email</label><input name="email" type="email" placeholder="email@domain.com"></div>
      </div>
      <div class="form-row" style="grid-template-columns: 1fr 1fr 2fr">
        <div class="form-group"><label>Tgl. Daftar *</label><input name="tgl_daftar" type="date" required value="<?= date('Y-m-d') ?>"></div>
        <div class="form-group"><label>Saldo Awal (Rp)</label><input name="saldo" type="number" value="0" min="0"></div>
        <div class="form-group" style="display:flex;align-items:flex-end"><button type="submit" class="btn btn-primary">➕ Tambah Pelanggan</button></div>
      </div>
    </form>
  </div>

  <div class="card">
    <div class="card-title">📋 Daftar Pelanggan</div>
    <table>
      <tr><th>ID</th><th>Nama</th><th>No. HP</th><th>Email</th><th>Tgl. Daftar</th><th>Saldo</th><th>Aksi</th></tr>
      <?php while ($row = $data->fetch_assoc()): ?>
      <tr>
        <td><?= $row['pelanggan_id'] ?></td>
        <td><?= htmlspecialchars($row['nama']) ?></td>
        <td><?= $row['no_hp'] ?></td>
        <td><?= $row['email'] ?? '-' ?></td>
        <td><?= date('d/m/Y', strtotime($row['tgl_daftar'])) ?></td>
        <td>Rp <?= number_format($row['saldo'], 0, ',', '.') ?></td>
        <td>
          <form method="POST" onsubmit="return confirm('Hapus pelanggan ini?')" style="display:inline">
            <input type="hidden" name="aksi" value="hapus">
            <input type="hidden" name="id" value="<?= $row['pelanggan_id'] ?>">
            <button type="submit" class="btn btn-danger">🗑 Hapus</button>
          </form>
        </td>
      </tr>
      <?php endwhile; ?>
    </table>
  </div>
</div>
</body>
</html>
