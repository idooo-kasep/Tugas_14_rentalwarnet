<?php
// koneksi.php - Konfigurasi koneksi database
$host     = 'localhost';
$user     = 'root';
$password = '';           // Default XAMPP tidak ada password
$database = 'db_rental_warnet';

$conn = new mysqli($host, $user, $password, $database);
$conn->set_charset('utf8mb4');

if ($conn->connect_error) {
    die('<div style="background:#f8d7da;color:#721c24;padding:15px;border-radius:5px;font-family:Arial">
         <b>Koneksi Gagal:</b> ' . $conn->connect_error . '
         <br><small>Pastikan XAMPP sudah dijalankan dan database sudah diimport.</small>
         </div>');
}
?>
