<?php
session_start();
if (!isset($_SESSION['user_id'])) { header('Location: login.php'); exit; }
require_once 'koneksi.php';

$msg = '';
// Mulai sesi baru
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['aksi'])) {
    if ($_POST['aksi'] === 'mulai') {
        $pid = intval($_POST['pelanggan_id']);
        $kid = intval($_POST['komputer_id']);
        $pakid = intval($_POST['paket_id']);
        $mulai = date('Y-m-d H:i:s');
        $stmt = $conn->prepare("INSERT INTO sesi (pelanggan_id, komputer_id, paket_id, waktu_mulai) VALUES (?,?,?,?)");
        $stmt->bind_param('iiis', $pid, $kid, $pakid, $mulai);
        if ($stmt->execute()) {
            $sid = $conn->insert_id;
            // Ambil harga paket
            $harga = $conn->query("SELECT harga FROM paket WHERE paket_id=$pakid")->fetch_assoc()['harga'];
            $uid = $_SESSION['user_id'];
            $conn->query("UPDATE komputer SET status='digunakan' WHERE komputer_id=$kid");
            // Insert transaksi langsung
            $stmt2 = $conn->prepare("INSERT INTO transaksi (sesi_id, user_id, total_bayar, metode_bayar) VALUES (?,?,?,'tunai')");
            $stmt2->bind_param('iid', $sid, $uid, $harga);
            $stmt2->execute();
            $msg = '<div class="alert-ok">✅ Sesi dimulai! Transaksi #'.$conn->insert_id.' dibuat.</div>';
        } else {
            $msg = '<div class="alert-err">❌ Gagal: ' . $conn->error . '</div>';
        }
    } elseif ($_POST['aksi'] === 'selesai') {
        $sid = intval($_POST['sesi_id']);
        $kid = intval($_POST['komputer_id']);
        $conn->query("UPDATE sesi SET status_sesi='selesai', waktu_selesai=NOW() WHERE sesi_id=$sid");
        $conn->query("UPDATE komputer SET status='tersedia' WHERE komputer_id=$kid");
        $msg = '<div class="alert-ok">✅ Sesi selesai. Komputer kembali tersedia.</div>';
    }
}

$aktif = $conn->query(
    "SELECT s.sesi_id, p.nama, k.nomor_unit, k.komputer_id, pk.nama_paket, s.waktu_mulai
     FROM sesi s
     JOIN pelanggan p ON s.pelanggan_id = p.pelanggan_id
     JOIN komputer k  ON s.komputer_id  = k.komputer_id
     JOIN paket pk    ON s.paket_id     = pk.paket_id
     WHERE s.status_sesi = 'aktif'
     ORDER BY s.waktu_mulai"
);

$pelanggan_list = $conn->query("SELECT pelanggan_id, nama FROM pelanggan ORDER BY nama");
$komputer_list  = $conn->query("SELECT komputer_id, nomor_unit FROM komputer WHERE status='tersedia'");
$paket_list     = $conn->query("SELECT paket_id, nama_paket, harga FROM paket ORDER BY harga");
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<title>Sesi - Rental Warnet</title>
<style>
  * { box-sizing: border-box; margin: 0; padding: 0; }
  body { font-family: 'Segoe UI', sans-serif; background: #0f0f23; color: #e0e0e0; }
  .sidebar { position: fixed; top: 0; left: 0; width: 240px; height: 100vh; background: #1a1a2e; border-right: 1px solid #2a2a4a; display: flex; flex-direction: column; }
  .sidebar-logo { padding: 20px; border-bottom: 1px solid #2a2a4a; font-size: 18px; font-weight: 700; color: #e94560; }
  .nav-item { display: flex; align-items: center; padding: 10px 20px; color: #aaa; text-decoration: none; font-size: 14px; transition: all 0.2s; }
  .nav-item:hover, .nav-item.active { background: #e9456015; color: #e94560; border-right: 3px solid #e94560; }
  .nav-item .icon { margin-right: 10px; }
  .nav-label { padding: 8px 20px; font-size: 10px; color: #555; text-transform: uppercase; letter-spacing: 1px; }
  .sidebar-footer { margin-top: auto; padding: 15px 20px; border-top: 1px solid #2a2a4a; font-size: 12px; color: #666; }
  .main { margin-left: 240px; padding: 25px; }
  .topbar { margin-bottom: 20px; }
  .topbar h1 { font-size: 22px; color: #fff; }
  .card { background: #1a1a2e; border: 1px solid #2a2a4a; border-radius: 12px; padding: 20px; margin-bottom: 20px; }
  .card-title { font-size: 15px; font-weight: 600; color: #fff; margin-bottom: 16px; padding-bottom: 12px; border-bottom: 1px solid #2a2a4a; }
  .form-row { display: grid; grid-template-columns: repeat(4,1fr); gap: 12px; }
  .form-group label { display: block; font-size: 12px; color: #888; margin-bottom: 5px; }
  .form-group select { width: 100%; padding: 10px; background: #0f0f23; border: 1px solid #2a2a4a; border-radius: 8px; color: #fff; font-size: 13px; }
  .form-group select:focus { outline: none; border-color: #e94560; }
  table { width: 100%; border-collapse: collapse; font-size: 13px; }
  th { padding: 10px 12px; text-align: left; color: #888; border-bottom: 1px solid #2a2a4a; }
  td { padding: 10px 12px; border-bottom: 1px solid #1e1e38; color: #ccc; }
  tr:hover td { background: #ffffff05; }
  .btn { padding: 10px 20px; border-radius: 8px; font-size: 13px; cursor: pointer; border: none; font-weight: 500; }
  .btn-primary { background: #e94560; color: #fff; }
  .btn-green   { background: #06d6a0; color: #000; padding: 6px 14px; font-size: 12px; }
  .btn:hover { opacity: 0.85; }
  .alert-ok  { background: #06d6a020; border: 1px solid #06d6a0; color: #06d6a0; padding: 10px 15px; border-radius: 8px; margin-bottom: 15px; }
  .alert-err { background: #e9456020; border: 1px solid #e94560; color: #e94560; padding: 10px 15px; border-radius: 8px; margin-bottom: 15px; }
  .badge-aktif { background: #ffd16620; color: #ffd166; padding: 3px 10px; border-radius: 12px; font-size: 11px; }
  .timer { font-family: monospace; font-size: 13px; color: #ffd166; }
</style>
</head>
<body>
<div class="sidebar">
  <div class="sidebar-logo">🖥️ Rental Warnet</div>
  <div class="nav-label">Menu Utama</div>
  <a href="dashboard.php" class="nav-item"><span class="icon">📊</span>Dashboard</a>
  <a href="pelanggan.php" class="nav-item"><span class="icon">👥</span>Pelanggan</a>
  <a href="komputer.php"  class="nav-item"><span class="icon">💻</span>Komputer</a>
  <a href="transaksi.php" class="nav-item"><span class="icon">💳</span>Transaksi</a>
  <a href="sesi.php"      class="nav-item active"><span class="icon">⏱️</span>Sesi Aktif</a>
  <?php if ($_SESSION['role'] === 'admin'): ?>
  <div class="nav-label">Admin</div>
  <a href="users.php"  class="nav-item"><span class="icon">🔐</span>Manajemen User</a>
  <a href="backup.php" class="nav-item"><span class="icon">💾</span>Backup & Restore</a>
  <?php endif; ?>
  <div class="sidebar-footer">
    <?= ucfirst($_SESSION['role']) ?> &nbsp;|&nbsp; <a href="logout.php" style="color:#e94560;text-decoration:none">Logout</a>
  </div>
</div>
<div class="main">
  <div class="topbar"><h1>⏱️ Sesi Aktif</h1></div>
  <?= $msg ?>

  <div class="card">
    <div class="card-title">▶️ Mulai Sesi Baru</div>
    <form method="POST">
      <input type="hidden" name="aksi" value="mulai">
      <div class="form-row">
        <div class="form-group">
          <label>Pelanggan *</label>
          <select name="pelanggan_id" required>
            <option value="">-- Pilih Pelanggan --</option>
            <?php while ($r = $pelanggan_list->fetch_assoc()): ?>
            <option value="<?= $r['pelanggan_id'] ?>"><?= htmlspecialchars($r['nama']) ?></option>
            <?php endwhile; ?>
          </select>
        </div>
        <div class="form-group">
          <label>Komputer (Tersedia) *</label>
          <select name="komputer_id" required>
            <option value="">-- Pilih PC --</option>
            <?php while ($r = $komputer_list->fetch_assoc()): ?>
            <option value="<?= $r['komputer_id'] ?>"><?= $r['nomor_unit'] ?></option>
            <?php endwhile; ?>
          </select>
        </div>
        <div class="form-group">
          <label>Paket *</label>
          <select name="paket_id" required>
            <option value="">-- Pilih Paket --</option>
            <?php while ($r = $paket_list->fetch_assoc()): ?>
            <option value="<?= $r['paket_id'] ?>"><?= htmlspecialchars($r['nama_paket']) ?> - Rp <?= number_format($r['harga'],0,',','.') ?></option>
            <?php endwhile; ?>
          </select>
        </div>
        <div class="form-group" style="display:flex;align-items:flex-end">
          <button type="submit" class="btn btn-primary">▶️ Mulai Sesi</button>
        </div>
      </div>
    </form>
  </div>

  <div class="card">
    <div class="card-title">🟡 Sesi Sedang Berlangsung</div>
    <?php if ($aktif->num_rows === 0): ?>
      <p style="color:#666;text-align:center;padding:20px">Tidak ada sesi aktif saat ini.</p>
    <?php else: ?>
    <table>
      <tr><th>Sesi ID</th><th>Pelanggan</th><th>PC</th><th>Paket</th><th>Mulai</th><th>Durasi</th><th>Aksi</th></tr>
      <?php while ($row = $aktif->fetch_assoc()): 
        $mulai_ts = strtotime($row['waktu_mulai']);
        $durasi_menit = round((time() - $mulai_ts) / 60);
      ?>
      <tr>
        <td><?= $row['sesi_id'] ?></td>
        <td><?= htmlspecialchars($row['nama']) ?></td>
        <td><?= $row['nomor_unit'] ?></td>
        <td><?= htmlspecialchars($row['nama_paket']) ?></td>
        <td><?= date('H:i', $mulai_ts) ?></td>
        <td class="timer"><?= $durasi_menit ?> menit</td>
        <td>
          <form method="POST" onsubmit="return confirm('Akhiri sesi ini?')">
            <input type="hidden" name="aksi" value="selesai">
            <input type="hidden" name="sesi_id" value="<?= $row['sesi_id'] ?>">
            <input type="hidden" name="komputer_id" value="<?= $row['komputer_id'] ?>">
            <button type="submit" class="btn btn-green">⏹ Selesai</button>
          </form>
        </td>
      </tr>
      <?php endwhile; ?>
    </table>
    <?php endif; ?>
  </div>
</div>
</body>
</html>
