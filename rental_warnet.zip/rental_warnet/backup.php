<?php
session_start();
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header('Location: dashboard.php'); exit;
}
require_once 'koneksi.php';

$msg = '';
$backup_dir = __DIR__ . '/backups/';
if (!is_dir($backup_dir)) mkdir($backup_dir, 0755, true);

// ============================================================
// PROSES BACKUP
// ============================================================
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['aksi'])) {

    if ($_POST['aksi'] === 'backup_full') {
        $filename = 'backup_warnet_full_' . date('Ymd_His') . '.sql';
        $filepath = $backup_dir . $filename;
        $tipe = $_POST['tipe_backup'] ?? 'full';

        // Generate SQL backup manual (agar tidak bergantung pada mysqldump)
        $sql = "-- ============================================================\n";
        $sql .= "-- Backup: db_rental_warnet\n";
        $sql .= "-- Dibuat: " . date('Y-m-d H:i:s') . "\n";
        $sql .= "-- Tipe: " . strtoupper($tipe) . "\n";
        $sql .= "-- Dibuat oleh: " . $_SESSION['nama_lengkap'] . " (" . $_SESSION['role'] . ")\n";
        $sql .= "-- ============================================================\n\n";
        $sql .= "SET FOREIGN_KEY_CHECKS=0;\n";
        $sql .= "SET SQL_MODE='NO_AUTO_VALUE_ON_ZERO';\n";
        $sql .= "SET NAMES utf8mb4;\n\n";
        $sql .= "CREATE DATABASE IF NOT EXISTS `db_rental_warnet`\n";
        $sql .= "    CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;\n";
        $sql .= "USE `db_rental_warnet`;\n\n";

        $tabel_target = ['users','pelanggan','komputer','paket','sesi','transaksi'];
        if ($tipe === 'selective' && !empty($_POST['tabel_pilih'])) {
            $tabel_target = $_POST['tabel_pilih'];
        }

        foreach ($tabel_target as $tbl) {
            // Struktur tabel
            if ($tipe !== 'data_only') {
                $create = $conn->query("SHOW CREATE TABLE `$tbl`");
                if ($create) {
                    $row_c = $create->fetch_assoc();
                    $sql .= "-- Struktur tabel: $tbl\n";
                    $sql .= "DROP TABLE IF EXISTS `$tbl`;\n";
                    $sql .= $row_c['Create Table'] . ";\n\n";
                }
            }
            // Data
            if ($tipe !== 'struktur_only') {
                $rows = $conn->query("SELECT * FROM `$tbl`");
                if ($rows && $rows->num_rows > 0) {
                    $sql .= "-- Data tabel: $tbl\n";
                    while ($row = $rows->fetch_assoc()) {
                        $vals = array_map(function($v) use ($conn) {
                            return $v === null ? 'NULL' : "'" . $conn->real_escape_string($v) . "'";
                        }, array_values($row));
                        $sql .= "INSERT INTO `$tbl` VALUES (" . implode(', ', $vals) . ");\n";
                    }
                    $sql .= "\n";
                } else {
                    $sql .= "-- (tabel $tbl kosong)\n\n";
                }
            }
        }
        $sql .= "SET FOREIGN_KEY_CHECKS=1;\n";
        $sql .= "-- ============================================================\n";
        $sql .= "-- Akhir backup: " . date('Y-m-d H:i:s') . "\n";
        $sql .= "-- ============================================================\n";

        file_put_contents($filepath, $sql);
        $size = number_format(filesize($filepath) / 1024, 1);
        $msg = "<div class='alert-ok'>✅ Backup berhasil! File: <b>$filename</b> ($size KB)</div>";
    }

    if ($_POST['aksi'] === 'restore') {
        if (isset($_FILES['file_sql']) && $_FILES['file_sql']['error'] === 0) {
            $tmpfile = $_FILES['file_sql']['tmp_name'];
            $sql_content = file_get_contents($tmpfile);
            
            // Jalankan query dari file SQL
            $conn->multi_query($sql_content);
            $errors = 0;
            do {
                if ($conn->errno) $errors++;
            } while ($conn->next_result());

            if ($errors === 0) {
                $msg = "<div class='alert-ok'>✅ Restore berhasil! Database dipulihkan dari file: <b>" . htmlspecialchars($_FILES['file_sql']['name']) . "</b></div>";
            } else {
                $msg = "<div class='alert-warn'>⚠️ Restore selesai dengan beberapa peringatan. Silakan verifikasi data.</div>";
            }
        } else {
            $msg = "<div class='alert-err'>❌ Tidak ada file yang dipilih atau gagal upload!</div>";
        }
    }

    if ($_POST['aksi'] === 'hapus_backup') {
        $file = basename($_POST['filename']);
        $path = $backup_dir . $file;
        if (file_exists($path) && pathinfo($path, PATHINFO_EXTENSION) === 'sql') {
            unlink($path);
            $msg = "<div class='alert-ok'>✅ File backup dihapus: $file</div>";
        }
    }
}

// Download backup
if (isset($_GET['download'])) {
    $file = basename($_GET['download']);
    $path = $backup_dir . $file;
    if (file_exists($path) && pathinfo($path, PATHINFO_EXTENSION) === 'sql') {
        header('Content-Type: application/octet-stream');
        header('Content-Disposition: attachment; filename="' . $file . '"');
        header('Content-Length: ' . filesize($path));
        readfile($path);
        exit;
    }
}

// Daftar file backup
$backup_files = glob($backup_dir . '*.sql') ?: [];
rsort($backup_files);

// Statistik tabel
$tabel_list = ['users','pelanggan','komputer','paket','sesi','transaksi'];
$tabel_stats = [];
foreach ($tabel_list as $t) {
    $r = $conn->query("SELECT COUNT(*) n FROM `$t`");
    $tabel_stats[$t] = $r ? $r->fetch_assoc()['n'] : 0;
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<title>Backup & Restore - Rental Warnet</title>
<style>
  * { box-sizing: border-box; margin: 0; padding: 0; }
  body { font-family: 'Segoe UI', sans-serif; background: #0f0f23; color: #e0e0e0; }
  .sidebar { position: fixed; top: 0; left: 0; width: 240px; height: 100vh; background: #1a1a2e; border-right: 1px solid #2a2a4a; display: flex; flex-direction: column; }
  .sidebar-logo { padding: 20px; border-bottom: 1px solid #2a2a4a; font-size: 18px; font-weight: 700; color: #e94560; }
  .nav-item { display: flex; align-items: center; padding: 10px 20px; color: #aaa; text-decoration: none; font-size: 14px; }
  .nav-item:hover, .nav-item.active { background: #e9456015; color: #e94560; border-right: 3px solid #e94560; }
  .nav-item .icon { margin-right: 10px; }
  .nav-label { padding: 8px 20px; font-size: 10px; color: #555; text-transform: uppercase; letter-spacing: 1px; }
  .sidebar-footer { margin-top: auto; padding: 15px 20px; border-top: 1px solid #2a2a4a; font-size: 12px; color: #666; }
  .main { margin-left: 240px; padding: 25px; }
  h1 { font-size: 22px; color: #fff; margin-bottom: 20px; }
  .grid2 { display: grid; grid-template-columns: 1fr 1fr; gap: 20px; }
  .card { background: #1a1a2e; border: 1px solid #2a2a4a; border-radius: 12px; padding: 20px; margin-bottom: 20px; }
  .card-title { font-size: 15px; font-weight: 600; color: #fff; margin-bottom: 16px; padding-bottom: 12px; border-bottom: 1px solid #2a2a4a; }
  .db-stats { display: grid; grid-template-columns: repeat(3,1fr); gap: 10px; margin-bottom: 20px; }
  .db-stat { background: #0f0f23; border: 1px solid #2a2a4a; border-radius: 8px; padding: 12px; text-align: center; }
  .db-stat .val { font-size: 22px; font-weight: 700; color: #e94560; }
  .db-stat .lbl { font-size: 11px; color: #666; margin-top: 3px; }

  .form-group { margin-bottom: 14px; }
  .form-group label { display: block; font-size: 12px; color: #888; margin-bottom: 5px; }
  .form-group select, .form-group input[type=file] {
    width: 100%; padding: 10px; background: #0f0f23;
    border: 1px solid #2a2a4a; border-radius: 8px; color: #fff; font-size: 13px;
  }
  .form-group select:focus { outline: none; border-color: #e94560; }
  .checkbox-group { display: flex; flex-wrap: wrap; gap: 8px; margin-top: 6px; }
  .checkbox-item { background: #0f0f23; border: 1px solid #2a2a4a; border-radius: 6px; padding: 6px 12px; font-size: 12px; display: flex; align-items: center; gap: 6px; cursor: pointer; }
  .checkbox-item:hover { border-color: #e94560; }
  .checkbox-item input { cursor: pointer; }
  #selective-options { display: none; }

  .btn { padding: 10px 20px; border-radius: 8px; font-size: 13px; cursor: pointer; border: none; font-weight: 500; }
  .btn-primary { background: #e94560; color: #fff; }
  .btn-blue    { background: #3a86ff; color: #fff; }
  .btn-green   { background: #06d6a0; color: #000; }
  .btn-sm      { padding: 5px 12px; font-size: 12px; }
  .btn:hover   { opacity: 0.85; }

  table { width: 100%; border-collapse: collapse; font-size: 13px; }
  th { padding: 10px 12px; text-align: left; color: #888; border-bottom: 1px solid #2a2a4a; }
  td { padding: 10px 12px; border-bottom: 1px solid #1e1e38; color: #ccc; }
  tr:hover td { background: #ffffff05; }

  .upload-area {
    border: 2px dashed #2a2a4a; border-radius: 10px; padding: 25px;
    text-align: center; color: #666; margin-bottom: 14px; cursor: pointer;
    transition: border-color 0.2s;
  }
  .upload-area:hover { border-color: #e94560; color: #e94560; }
  .upload-area input[type=file] { display: none; }
  .upload-area .icon { font-size: 32px; display: block; margin-bottom: 8px; }

  .alert-ok   { background: #06d6a020; border: 1px solid #06d6a0; color: #06d6a0; padding: 12px 15px; border-radius: 8px; margin-bottom: 15px; }
  .alert-err  { background: #e9456020; border: 1px solid #e94560; color: #e94560; padding: 12px 15px; border-radius: 8px; margin-bottom: 15px; }
  .alert-warn { background: #ffd16620; border: 1px solid #ffd166; color: #ffd166; padding: 12px 15px; border-radius: 8px; margin-bottom: 15px; }

  .cmd-block {
    background: #0a0a18; border: 1px solid #2a2a4a; border-radius: 8px;
    padding: 15px; font-family: 'Courier New', monospace; font-size: 12px;
    color: #06d6a0; white-space: pre-wrap; margin: 10px 0;
    line-height: 1.6;
  }
  .cmd-comment { color: #555; }
</style>
</head>
<body>
<div class="sidebar">
  <div class="sidebar-logo">🖥️ Rental Warnet</div>
  <div class="nav-label">Menu Utama</div>
  <a href="dashboard.php" class="nav-item"><span class="icon">📊</span>Dashboard</a>
  <a href="pelanggan.php" class="nav-item"><span class="icon">👥</span>Pelanggan</a>
  <a href="komputer.php"  class="nav-item"><span class="icon">💻</span>Komputer</a>
  <a href="transaksi.php" class="nav-item"><span class="icon">💳</span>Transaksi</a>
  <a href="sesi.php"      class="nav-item"><span class="icon">⏱️</span>Sesi Aktif</a>
  <div class="nav-label">Admin</div>
  <a href="users.php"  class="nav-item"><span class="icon">🔐</span>Manajemen User</a>
  <a href="backup.php" class="nav-item active"><span class="icon">💾</span>Backup & Restore</a>
  <div class="sidebar-footer">
    Admin &nbsp;|&nbsp; <a href="logout.php" style="color:#e94560;text-decoration:none">Logout</a>
  </div>
</div>
<div class="main">
  <h1>💾 Backup & Restore Database</h1>
  <?= $msg ?>

  <!-- Status Database -->
  <div class="card">
    <div class="card-title">📊 Status Database: <span style="color:#e94560">db_rental_warnet</span></div>
    <div class="db-stats">
      <?php foreach ($tabel_stats as $tbl => $n): ?>
      <div class="db-stat">
        <div class="val"><?= $n ?></div>
        <div class="lbl"><?= $tbl ?></div>
      </div>
      <?php endforeach; ?>
    </div>
  </div>

  <div class="grid2">

    <!-- BACKUP -->
    <div>
      <div class="card">
        <div class="card-title">📤 Backup Database</div>
        <form method="POST">
          <input type="hidden" name="aksi" value="backup_full">
          <div class="form-group">
            <label>Jenis Backup</label>
            <select name="tipe_backup" id="tipe_select" onchange="toggleSelective(this.value)">
              <option value="full">Full Backup (Semua tabel + data)</option>
              <option value="selective">Selective Backup (Pilih tabel)</option>
              <option value="struktur_only">Struktur Saja (Tanpa data)</option>
              <option value="data_only">Data Saja (Tanpa struktur)</option>
            </select>
          </div>
          <div id="selective-options">
            <div class="form-group">
              <label>Pilih Tabel yang Akan Dibackup:</label>
              <div class="checkbox-group">
                <?php foreach ($tabel_list as $t): ?>
                <label class="checkbox-item">
                  <input type="checkbox" name="tabel_pilih[]" value="<?= $t ?>" checked>
                  <?= $t ?>
                </label>
                <?php endforeach; ?>
              </div>
            </div>
          </div>
          <button type="submit" class="btn btn-primary">💾 Jalankan Backup</button>
        </form>
      </div>

      <!-- Perintah mysqldump -->
      <div class="card">
        <div class="card-title">🖥️ Perintah mysqldump (CMD/Terminal)</div>
        <p style="color:#888;font-size:12px;margin-bottom:10px">Full backup via command line:</p>
        <div class="cmd-block"><span class="cmd-comment">-- Jalankan di CMD/Terminal XAMPP:</span>
cd C:\xampp\mysql\bin

mysqldump -u root -p ^
  --databases db_rental_warnet ^
  --add-drop-database ^
  --add-drop-table ^
  --routines --triggers ^
  --result-file=backup_warnet_full_<?= date('Ymd') ?>.sql

<span class="cmd-comment">-- Restore dari file backup:</span>
mysql -u root -p < backup_warnet_full_<?= date('Ymd') ?>.sql</div>
      </div>
    </div>

    <!-- RESTORE -->
    <div>
      <div class="card">
        <div class="card-title">📥 Restore Database</div>
        <p style="color:#ffd166;font-size:12px;margin-bottom:15px">⚠️ Perhatian: Restore akan menimpa data yang ada!</p>
        <form method="POST" enctype="multipart/form-data">
          <input type="hidden" name="aksi" value="restore">
          <label class="upload-area" for="file_sql_input">
            <span class="icon">📂</span>
            Klik untuk pilih file backup (.sql)<br>
            <span id="file_label" style="font-size:11px;color:#555">Belum ada file dipilih</span>
            <input type="file" name="file_sql" id="file_sql_input" accept=".sql"
                   onchange="document.getElementById('file_label').textContent = this.files[0]?.name || 'Belum ada file'">
          </label>
          <button type="submit" class="btn btn-blue" onclick="return confirm('Yakin ingin merestore database? Data saat ini akan tertimpa!')">
            🔄 Jalankan Restore
          </button>
        </form>
      </div>

      <!-- File Backup Tersimpan -->
      <div class="card">
        <div class="card-title">📁 File Backup Tersimpan</div>
        <?php if (empty($backup_files)): ?>
          <p style="color:#666;text-align:center;padding:15px">Belum ada file backup.</p>
        <?php else: ?>
        <table>
          <tr><th>Nama File</th><th>Ukuran</th><th>Tanggal</th><th>Aksi</th></tr>
          <?php foreach ($backup_files as $f): 
            $fname = basename($f);
            $size  = number_format(filesize($f) / 1024, 1) . ' KB';
            $mtime = date('d/m/Y H:i', filemtime($f));
          ?>
          <tr>
            <td style="font-family:monospace;font-size:11px"><?= $fname ?></td>
            <td><?= $size ?></td>
            <td><?= $mtime ?></td>
            <td style="display:flex;gap:6px">
              <a href="?download=<?= urlencode($fname) ?>" class="btn btn-sm btn-green">⬇ DL</a>
              <form method="POST" onsubmit="return confirm('Hapus file backup ini?')" style="display:inline">
                <input type="hidden" name="aksi" value="hapus_backup">
                <input type="hidden" name="filename" value="<?= $fname ?>">
                <button type="submit" class="btn btn-sm" style="background:#e9456020;color:#e94560;border:1px solid #e9456040">🗑</button>
              </form>
            </td>
          </tr>
          <?php endforeach; ?>
        </table>
        <?php endif; ?>
      </div>
    </div>

  </div><!-- .grid2 -->

  <!-- Jadwal Backup -->
  <div class="card">
    <div class="card-title">📅 Rekomendasi Jadwal Backup</div>
    <table>
      <tr><th>Jenis</th><th>Frekuensi</th><th>Waktu</th><th>Keterangan</th></tr>
      <tr><td>Full Backup</td><td>Mingguan</td><td>Senin 05:00</td><td>Backup lengkap semua tabel</td></tr>
      <tr><td>Incremental</td><td>Harian</td><td>Setiap hari 23:59</td><td>Backup data transaksi hari ini</td></tr>
      <tr><td>Tabel transaksi</td><td>2x sehari</td><td>12:00 & 23:00</td><td>Data keuangan kritis</td></tr>
      <tr><td>Tabel users</td><td>Setiap perubahan</td><td>Otomatis</td><td>Setelah add/edit user</td></tr>
    </table>
  </div>

</div>

<script>
function toggleSelective(val) {
  document.getElementById('selective-options').style.display =
    val === 'selective' ? 'block' : 'none';
}
</script>
</body>
</html>
