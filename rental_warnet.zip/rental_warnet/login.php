<?php
session_start();
if (isset($_SESSION['user_id'])) {
    header('Location: dashboard.php');
    exit;
}

require_once 'koneksi.php';

$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';

    if ($username && $password) {
        $hash = hash('sha256', $password);
        $stmt = $conn->prepare(
            "SELECT user_id, username, nama_lengkap, role 
             FROM users 
             WHERE username = ? AND password_hash = ? AND status = 'aktif'"
        );
        $stmt->bind_param('ss', $username, $hash);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows === 1) {
            $user = $result->fetch_assoc();
            $_SESSION['user_id']      = $user['user_id'];
            $_SESSION['username']     = $user['username'];
            $_SESSION['nama_lengkap'] = $user['nama_lengkap'];
            $_SESSION['role']         = $user['role'];

            // Update waktu login terakhir
            $upd = $conn->prepare("UPDATE users SET terakhir_login = NOW() WHERE user_id = ?");
            $upd->bind_param('i', $user['user_id']);
            $upd->execute();

            header('Location: dashboard.php');
            exit;
        } else {
            $error = 'Username atau password salah!';
        }
    } else {
        $error = 'Username dan password wajib diisi!';
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Login - Rental Warnet</title>
<style>
  * { box-sizing: border-box; margin: 0; padding: 0; }
  body {
    font-family: 'Segoe UI', sans-serif;
    background: linear-gradient(135deg, #1a1a2e 0%, #16213e 50%, #0f3460 100%);
    min-height: 100vh;
    display: flex;
    align-items: center;
    justify-content: center;
  }
  .login-wrapper {
    background: rgba(255,255,255,0.05);
    backdrop-filter: blur(10px);
    border: 1px solid rgba(255,255,255,0.1);
    border-radius: 16px;
    padding: 40px;
    width: 400px;
    box-shadow: 0 20px 60px rgba(0,0,0,0.5);
  }
  .logo {
    text-align: center;
    margin-bottom: 30px;
  }
  .logo .icon {
    font-size: 48px;
    display: block;
    margin-bottom: 10px;
  }
  .logo h1 {
    color: #e94560;
    font-size: 24px;
    font-weight: 700;
  }
  .logo p { color: #aaa; font-size: 13px; margin-top: 4px; }
  .form-group { margin-bottom: 20px; }
  label { display: block; color: #ccc; font-size: 13px; margin-bottom: 6px; }
  input {
    width: 100%;
    padding: 12px 15px;
    background: rgba(255,255,255,0.08);
    border: 1px solid rgba(255,255,255,0.15);
    border-radius: 8px;
    color: #fff;
    font-size: 14px;
    transition: border-color 0.3s;
  }
  input:focus { outline: none; border-color: #e94560; }
  .btn-login {
    width: 100%;
    padding: 13px;
    background: #e94560;
    color: #fff;
    border: none;
    border-radius: 8px;
    font-size: 16px;
    font-weight: 600;
    cursor: pointer;
    transition: background 0.3s;
  }
  .btn-login:hover { background: #c73652; }
  .error {
    background: rgba(233,69,96,0.2);
    border: 1px solid #e94560;
    color: #ff8fa3;
    padding: 10px 15px;
    border-radius: 8px;
    font-size: 13px;
    margin-bottom: 20px;
  }
  .hint {
    text-align: center;
    color: #666;
    font-size: 12px;
    margin-top: 20px;
  }
  .hint span { color: #e94560; }
</style>
</head>
<body>
<div class="login-wrapper">
  <div class="logo">
    <span class="icon">🖥️</span>
    <h1>Rental Warnet</h1>
    <p>Sistem Database Manajemen Warnet</p>
  </div>

  <?php if ($error): ?>
    <div class="error">⚠️ <?= htmlspecialchars($error) ?></div>
  <?php endif; ?>

  <form method="POST">
    <div class="form-group">
      <label>Username</label>
      <input type="text" name="username" placeholder="Masukkan username" 
             value="<?= htmlspecialchars($_POST['username'] ?? '') ?>" required>
    </div>
    <div class="form-group">
      <label>Password</label>
      <input type="password" name="password" placeholder="Masukkan password" required>
    </div>
    <button type="submit" class="btn-login">🔐 Login</button>
  </form>

  <div class="hint">
    Demo: <span>admin</span> / <span>admin123</span> &nbsp;|&nbsp; 
    <span>operator1</span> / <span>operator123</span>
  </div>
</div>
</body>
</html>
