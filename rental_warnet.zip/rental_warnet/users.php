<?php
session_start();
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header('Location: dashboard.php'); exit;
}
require_once 'koneksi.php';

$msg = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['aksi'])) {
    if ($_POST['aksi'] === 'tambah') {
        $uname = trim($_POST['username']);
        $pass  = SHA2($_POST['password'], 256); // Gunakan PHP hash
        $pass  = hash('sha256', $_POST['password']);
        $nama  = trim($_POST['nama_lengkap']);
        $role  = $_POST['role'];
        $stmt  = $conn->prepare("INSERT INTO users (username, password_hash, nama_lengkap, role) VALUES (?,?,?,?)");
        $stmt->bind_param('ssss', $uname, $pass, $nama, $role);
        if ($stmt->execute()) $msg = '<div class="alert-ok">✅ User berhasil ditambahkan!</div>';
        else $msg = '<div class="alert-err">❌ Gagal: ' . $conn->error . '</div>';
    } elseif ($_POST['aksi'] === 'ubah_status') {
        $id = intval($_POST['id']);
        $status = $_POST['status'];
        $conn->query("UPDATE users SET status='$status' WHERE user_id=$id");
        $msg = '<div class="alert-ok">✅ Status user diperbarui.</div>';
    } elseif ($_POST['aksi'] === 'hapus') {
        $id = intval($_POST['id']);
        if ($id == $_SESSION['user_id']) {
            $msg = '<div class="alert-err">❌ Tidak bisa menghapus akun sendiri!</div>';
        } else {
            $conn->query("DELETE FROM users WHERE user_id=$id");
            $msg = '<div class="alert-ok">✅ User dihapus.</div>';
        }
    }
}

$data = $conn->query("SELECT * FROM users ORDER BY role, username");
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<title>Manajemen User - Rental Warnet</title>
<style>
  * { box-sizing: border-box; margin: 0; padding: 0; }
  body { font-family: 'Segoe UI', sans-serif; background: #0f0f23; color: #e0e0e0; }
  .sidebar { position: fixed; top: 0; left: 0; width: 240px; height: 100vh; background: #1a1a2e; border-right: 1px solid #2a2a4a; display: flex; flex-direction: column; }
  .sidebar-logo { padding: 20px; border-bottom: 1px solid #2a2a4a; font-size: 18px; font-weight: 700; color: #e94560; }
  .nav-item { display: flex; align-items: center; padding: 10px 20px; color: #aaa; text-decoration: none; font-size: 14px; }
  .nav-item:hover, .nav-item.active { background: #e9456015; color: #e94560; border-right: 3px solid #e94560; }
  .nav-item .icon { margin-right: 10px; }
  .nav-label { padding: 8px 20px; font-size: 10px; color: #555; text-transform: uppercase; letter-spacing: 1px; }
  .sidebar-footer { margin-top: auto; padding: 15px 20px; border-top: 1px solid #2a2a4a; font-size: 12px; color: #666; }
  .main { margin-left: 240px; padding: 25px; }
  .card { background: #1a1a2e; border: 1px solid #2a2a4a; border-radius: 12px; padding: 20px; margin-bottom: 20px; }
  .card-title { font-size: 15px; font-weight: 600; color: #fff; margin-bottom: 16px; padding-bottom: 12px; border-bottom: 1px solid #2a2a4a; }
  .form-row { display: grid; grid-template-columns: repeat(4,1fr); gap: 12px; }
  .form-group label { display: block; font-size: 12px; color: #888; margin-bottom: 5px; }
  .form-group input, .form-group select { width: 100%; padding: 10px; background: #0f0f23; border: 1px solid #2a2a4a; border-radius: 8px; color: #fff; font-size: 13px; }
  .form-group input:focus, .form-group select:focus { outline: none; border-color: #e94560; }
  table { width: 100%; border-collapse: collapse; font-size: 13px; }
  th { padding: 10px 12px; text-align: left; color: #888; border-bottom: 1px solid #2a2a4a; }
  td { padding: 10px 12px; border-bottom: 1px solid #1e1e38; color: #ccc; }
  tr:hover td { background: #ffffff05; }
  .badge { padding: 3px 10px; border-radius: 12px; font-size: 11px; font-weight: 500; }
  .badge-admin    { background: #e9456020; color: #e94560; }
  .badge-operator { background: #3a86ff20; color: #3a86ff; }
  .badge-aktif    { background: #06d6a020; color: #06d6a0; }
  .badge-nonaktif { background: #55555520; color: #888; }
  .btn { padding: 8px 16px; border-radius: 8px; font-size: 13px; cursor: pointer; border: none; }
  .btn-primary { background: #e94560; color: #fff; padding: 10px 20px; }
  .btn-sm { padding: 4px 10px; font-size: 11px; }
  .btn-green { background: #06d6a0; color: #000; }
  .btn-red   { background: #e94560; color: #fff; }
  .btn:hover { opacity: 0.85; }
  .alert-ok  { background: #06d6a020; border: 1px solid #06d6a0; color: #06d6a0; padding: 10px 15px; border-radius: 8px; margin-bottom: 15px; }
  .alert-err { background: #e9456020; border: 1px solid #e94560; color: #e94560; padding: 10px 15px; border-radius: 8px; margin-bottom: 15px; }
</style>
</head>
<body>
<div class="sidebar">
  <div class="sidebar-logo">🖥️ Rental Warnet</div>
  <div class="nav-label">Menu Utama</div>
  <a href="dashboard.php" class="nav-item"><span class="icon">📊</span>Dashboard</a>
  <a href="pelanggan.php" class="nav-item"><span class="icon">👥</span>Pelanggan</a>
  <a href="komputer.php"  class="nav-item"><span class="icon">💻</span>Komputer</a>
  <a href="transaksi.php" class="nav-item"><span class="icon">💳</span>Transaksi</a>
  <a href="sesi.php"      class="nav-item"><span class="icon">⏱️</span>Sesi Aktif</a>
  <div class="nav-label">Admin</div>
  <a href="users.php"  class="nav-item active"><span class="icon">🔐</span>Manajemen User</a>
  <a href="backup.php" class="nav-item"><span class="icon">💾</span>Backup & Restore</a>
  <div class="sidebar-footer">
    Admin &nbsp;|&nbsp; <a href="logout.php" style="color:#e94560;text-decoration:none">Logout</a>
  </div>
</div>
<div class="main">
  <h1 style="color:#fff;margin-bottom:20px">🔐 Manajemen User</h1>
  <?= $msg ?>

  <div class="card">
    <div class="card-title">➕ Tambah User Baru</div>
    <form method="POST">
      <input type="hidden" name="aksi" value="tambah">
      <div class="form-row">
        <div class="form-group"><label>Username *</label><input name="username" required placeholder="username123"></div>
        <div class="form-group"><label>Password *</label><input name="password" type="password" required placeholder="••••••••"></div>
        <div class="form-group"><label>Nama Lengkap *</label><input name="nama_lengkap" required placeholder="Nama lengkap"></div>
        <div class="form-group"><label>Role *</label>
          <select name="role">
            <option value="operator">Operator</option>
            <option value="admin">Admin</option>
          </select>
        </div>
      </div>
      <button type="submit" class="btn btn-primary" style="margin-top:8px">➕ Tambah User</button>
    </form>
  </div>

  <div class="card">
    <div class="card-title">📋 Daftar User</div>
    <table>
      <tr><th>ID</th><th>Username</th><th>Nama Lengkap</th><th>Role</th><th>Status</th><th>Login Terakhir</th><th>Ubah Status</th><th>Hapus</th></tr>
      <?php while ($row = $data->fetch_assoc()): ?>
      <tr>
        <td><?= $row['user_id'] ?></td>
        <td><?= htmlspecialchars($row['username']) ?></td>
        <td><?= htmlspecialchars($row['nama_lengkap']) ?></td>
        <td><span class="badge badge-<?= $row['role'] ?>"><?= $row['role'] ?></span></td>
        <td><span class="badge badge-<?= $row['status'] ?>"><?= $row['status'] ?></span></td>
        <td><?= $row['terakhir_login'] ? date('d/m/Y H:i', strtotime($row['terakhir_login'])) : '-' ?></td>
        <td>
          <form method="POST" style="display:flex;gap:4px">
            <input type="hidden" name="aksi" value="ubah_status">
            <input type="hidden" name="id" value="<?= $row['user_id'] ?>">
            <select name="status" style="background:#0f0f23;color:#ccc;border:1px solid #2a2a4a;border-radius:6px;padding:4px;font-size:11px">
              <option <?= $row['status']=='aktif'?'selected':'' ?>>aktif</option>
              <option <?= $row['status']=='nonaktif'?'selected':'' ?>>nonaktif</option>
            </select>
            <button type="submit" class="btn btn-sm btn-green">✓</button>
          </form>
        </td>
        <td>
          <?php if ($row['user_id'] != $_SESSION['user_id']): ?>
          <form method="POST" onsubmit="return confirm('Hapus user ini?')" style="display:inline">
            <input type="hidden" name="aksi" value="hapus">
            <input type="hidden" name="id" value="<?= $row['user_id'] ?>">
            <button type="submit" class="btn btn-sm btn-red">🗑</button>
          </form>
          <?php else: ?>
          <span style="color:#555;font-size:11px">Akun ini</span>
          <?php endif; ?>
        </td>
      </tr>
      <?php endwhile; ?>
    </table>
  </div>
</div>
</body>
</html>
