<?php
session_start();
if (!isset($_SESSION['user_id'])) { header('Location: login.php'); exit; }
require_once 'koneksi.php';

// Ambil statistik
$stats = [];
foreach (['users','pelanggan','komputer','paket','sesi','transaksi'] as $tbl) {
    $r = $conn->query("SELECT COUNT(*) AS n FROM $tbl");
    $stats[$tbl] = $r->fetch_assoc()['n'];
}

// Total pendapatan
$rev = $conn->query("SELECT SUM(total_bayar) AS total FROM transaksi");
$total_rev = $rev->fetch_assoc()['total'] ?? 0;

// Komputer tersedia
$avail = $conn->query("SELECT COUNT(*) AS n FROM komputer WHERE status='tersedia'");
$tersedia = $avail->fetch_assoc()['n'];

// Transaksi terbaru
$recent = $conn->query(
    "SELECT t.transaksi_id, p.nama AS pelanggan, k.nomor_unit, pk.nama_paket,
            t.total_bayar, t.metode_bayar, t.waktu_transaksi
     FROM transaksi t
     JOIN sesi s     ON t.sesi_id      = s.sesi_id
     JOIN pelanggan p ON s.pelanggan_id = p.pelanggan_id
     JOIN komputer k  ON s.komputer_id  = k.komputer_id
     JOIN paket pk    ON s.paket_id     = pk.paket_id
     ORDER BY t.waktu_transaksi DESC
     LIMIT 5"
);
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Dashboard - Rental Warnet</title>
<style>
  * { box-sizing: border-box; margin: 0; padding: 0; }
  body { font-family: 'Segoe UI', sans-serif; background: #0f0f23; color: #e0e0e0; }

  /* Sidebar */
  .sidebar {
    position: fixed; top: 0; left: 0; width: 240px; height: 100vh;
    background: #1a1a2e; border-right: 1px solid #2a2a4a;
    display: flex; flex-direction: column;
  }
  .sidebar-logo {
    padding: 20px; border-bottom: 1px solid #2a2a4a;
    font-size: 18px; font-weight: 700; color: #e94560;
  }
  .sidebar-logo span { font-size: 24px; margin-right: 8px; }
  .nav-section { padding: 10px 0; }
  .nav-label { padding: 8px 20px; font-size: 10px; color: #555; text-transform: uppercase; letter-spacing: 1px; }
  .nav-item {
    display: flex; align-items: center; padding: 10px 20px;
    color: #aaa; text-decoration: none; font-size: 14px;
    transition: all 0.2s;
  }
  .nav-item:hover, .nav-item.active { background: #e9456015; color: #e94560; border-right: 3px solid #e94560; }
  .nav-item .icon { margin-right: 10px; font-size: 16px; }
  .sidebar-footer {
    margin-top: auto; padding: 15px 20px; border-top: 1px solid #2a2a4a;
    font-size: 12px; color: #666;
  }

  /* Main */
  .main { margin-left: 240px; padding: 25px; }
  .topbar {
    display: flex; justify-content: space-between; align-items: center;
    margin-bottom: 25px;
  }
  .topbar h1 { font-size: 22px; color: #fff; }
  .user-badge {
    background: #e9456020; border: 1px solid #e9456040;
    padding: 6px 14px; border-radius: 20px; font-size: 13px; color: #e94560;
  }

  /* Stats grid */
  .stats-grid {
    display: grid; grid-template-columns: repeat(4, 1fr); gap: 16px;
    margin-bottom: 25px;
  }
  .stat-card {
    background: #1a1a2e; border: 1px solid #2a2a4a; border-radius: 12px;
    padding: 20px;
  }
  .stat-card .label { font-size: 12px; color: #888; margin-bottom: 8px; }
  .stat-card .value { font-size: 28px; font-weight: 700; color: #fff; }
  .stat-card .sub { font-size: 11px; color: #555; margin-top: 4px; }
  .stat-card.red   { border-color: #e9456040; }
  .stat-card.blue  { border-color: #3a86ff40; }
  .stat-card.green { border-color: #06d6a040; }
  .stat-card.purple{ border-color: #9b5de540; }

  /* Table card */
  .card {
    background: #1a1a2e; border: 1px solid #2a2a4a; border-radius: 12px;
    padding: 20px; margin-bottom: 20px;
  }
  .card-title {
    font-size: 15px; font-weight: 600; color: #fff;
    margin-bottom: 16px; padding-bottom: 12px; border-bottom: 1px solid #2a2a4a;
  }
  table { width: 100%; border-collapse: collapse; font-size: 13px; }
  th { padding: 10px 12px; text-align: left; color: #888; font-weight: 500; border-bottom: 1px solid #2a2a4a; }
  td { padding: 10px 12px; border-bottom: 1px solid #1e1e38; color: #ccc; }
  tr:last-child td { border-bottom: none; }
  tr:hover td { background: #ffffff05; }

  .badge {
    padding: 3px 10px; border-radius: 12px; font-size: 11px; font-weight: 500;
  }
  .badge-tunai    { background: #06d6a020; color: #06d6a0; }
  .badge-transfer { background: #3a86ff20; color: #3a86ff; }
  .badge-saldo    { background: #9b5de520; color: #9b5de5; }

  .btn { 
    padding: 8px 16px; border-radius: 8px; font-size: 13px; font-weight: 500;
    text-decoration: none; cursor: pointer; border: none; display: inline-block;
  }
  .btn-primary { background: #e94560; color: #fff; }
  .btn-outline { background: transparent; color: #e94560; border: 1px solid #e94560; }
  .btn:hover { opacity: 0.85; }

  .quick-links { display: grid; grid-template-columns: repeat(3,1fr); gap: 12px; }
  .quick-link {
    background: #0f0f23; border: 1px solid #2a2a4a; border-radius: 10px;
    padding: 15px; text-align: center; text-decoration: none; color: #ccc;
    transition: all 0.2s; display: block;
  }
  .quick-link:hover { border-color: #e94560; color: #e94560; }
  .quick-link .ql-icon { font-size: 28px; display: block; margin-bottom: 6px; }
  .quick-link .ql-label { font-size: 12px; }
</style>
</head>
<body>

<!-- Sidebar -->
<div class="sidebar">
  <div class="sidebar-logo"><span>🖥️</span>Rental Warnet</div>
  <div class="nav-section">
    <div class="nav-label">Menu Utama</div>
    <a href="dashboard.php" class="nav-item active"><span class="icon">📊</span>Dashboard</a>
    <a href="pelanggan.php" class="nav-item"><span class="icon">👥</span>Pelanggan</a>
    <a href="komputer.php"  class="nav-item"><span class="icon">💻</span>Komputer</a>
    <a href="transaksi.php" class="nav-item"><span class="icon">💳</span>Transaksi</a>
    <a href="sesi.php"      class="nav-item"><span class="icon">⏱️</span>Sesi Aktif</a>
  </div>
  <?php if ($_SESSION['role'] === 'admin'): ?>
  <div class="nav-section">
    <div class="nav-label">Admin</div>
    <a href="users.php"   class="nav-item"><span class="icon">🔐</span>Manajemen User</a>
    <a href="backup.php"  class="nav-item"><span class="icon">💾</span>Backup & Restore</a>
  </div>
  <?php endif; ?>
  <div class="sidebar-footer">
    Role: <?= ucfirst($_SESSION['role']) ?><br>
    <a href="logout.php" style="color:#e94560;text-decoration:none">🚪 Logout</a>
  </div>
</div>

<!-- Main Content -->
<div class="main">
  <div class="topbar">
    <h1>📊 Dashboard</h1>
    <div class="user-badge">👤 <?= htmlspecialchars($_SESSION['nama_lengkap']) ?> (<?= $_SESSION['role'] ?>)</div>
  </div>

  <!-- Stats -->
  <div class="stats-grid">
    <div class="stat-card red">
      <div class="label">💰 Total Pendapatan</div>
      <div class="value">Rp <?= number_format($total_rev, 0, ',', '.') ?></div>
      <div class="sub"><?= $stats['transaksi'] ?> transaksi</div>
    </div>
    <div class="stat-card blue">
      <div class="label">👥 Total Pelanggan</div>
      <div class="value"><?= $stats['pelanggan'] ?></div>
      <div class="sub">Member terdaftar</div>
    </div>
    <div class="stat-card green">
      <div class="label">💻 PC Tersedia</div>
      <div class="value"><?= $tersedia ?> / <?= $stats['komputer'] ?></div>
      <div class="sub">Unit aktif</div>
    </div>
    <div class="stat-card purple">
      <div class="label">📦 Paket Tersedia</div>
      <div class="value"><?= $stats['paket'] ?></div>
      <div class="sub">Paket internet</div>
    </div>
  </div>

  <!-- Shortcut -->
  <div class="card">
    <div class="card-title">⚡ Akses Cepat</div>
    <div class="quick-links">
      <a href="pelanggan.php" class="quick-link">
        <span class="ql-icon">👥</span>
        <span class="ql-label">Data Pelanggan</span>
      </a>
      <a href="komputer.php" class="quick-link">
        <span class="ql-icon">💻</span>
        <span class="ql-label">Data Komputer</span>
      </a>
      <a href="transaksi.php" class="quick-link">
        <span class="ql-icon">💳</span>
        <span class="ql-label">Lihat Transaksi</span>
      </a>
      <a href="sesi.php" class="quick-link">
        <span class="ql-icon">⏱️</span>
        <span class="ql-label">Sesi Aktif</span>
      </a>
      <?php if ($_SESSION['role'] === 'admin'): ?>
      <a href="users.php" class="quick-link">
        <span class="ql-icon">🔐</span>
        <span class="ql-label">Kelola User</span>
      </a>
      <a href="backup.php" class="quick-link">
        <span class="ql-icon">💾</span>
        <span class="ql-label">Backup & Restore</span>
      </a>
      <?php endif; ?>
    </div>
  </div>

  <!-- Transaksi Terbaru -->
  <div class="card">
    <div class="card-title">💳 Transaksi Terbaru</div>
    <table>
      <tr>
        <th>#</th><th>Pelanggan</th><th>PC</th><th>Paket</th>
        <th>Total</th><th>Metode</th><th>Waktu</th>
      </tr>
      <?php while ($row = $recent->fetch_assoc()): ?>
      <tr>
        <td><?= $row['transaksi_id'] ?></td>
        <td><?= htmlspecialchars($row['pelanggan']) ?></td>
        <td><?= $row['nomor_unit'] ?></td>
        <td><?= htmlspecialchars($row['nama_paket']) ?></td>
        <td>Rp <?= number_format($row['total_bayar'], 0, ',', '.') ?></td>
        <td><span class="badge badge-<?= $row['metode_bayar'] ?>"><?= $row['metode_bayar'] ?></span></td>
        <td><?= date('d/m/Y H:i', strtotime($row['waktu_transaksi'])) ?></td>
      </tr>
      <?php endwhile; ?>
    </table>
  </div>
</div>
</body>
</html>
