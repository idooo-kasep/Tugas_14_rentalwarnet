<?php
session_start();
if (!isset($_SESSION['user_id'])) { header('Location: login.php'); exit; }
require_once 'koneksi.php';

$data = $conn->query(
    "SELECT t.transaksi_id, p.nama AS pelanggan, k.nomor_unit, pk.nama_paket,
            s.waktu_mulai, s.waktu_selesai,
            t.total_bayar, t.metode_bayar, t.waktu_transaksi,
            u.username AS kasir
     FROM transaksi t
     JOIN sesi s      ON t.sesi_id      = s.sesi_id
     JOIN pelanggan p ON s.pelanggan_id = p.pelanggan_id
     JOIN komputer k  ON s.komputer_id  = k.komputer_id
     JOIN paket pk    ON s.paket_id     = pk.paket_id
     JOIN users u     ON t.user_id      = u.user_id
     ORDER BY t.waktu_transaksi DESC"
);
$total = $conn->query("SELECT SUM(total_bayar) t, COUNT(*) n FROM transaksi")->fetch_assoc();
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<title>Transaksi - Rental Warnet</title>
<style>
  * { box-sizing: border-box; margin: 0; padding: 0; }
  body { font-family: 'Segoe UI', sans-serif; background: #0f0f23; color: #e0e0e0; }
  .sidebar { position: fixed; top: 0; left: 0; width: 240px; height: 100vh; background: #1a1a2e; border-right: 1px solid #2a2a4a; display: flex; flex-direction: column; }
  .sidebar-logo { padding: 20px; border-bottom: 1px solid #2a2a4a; font-size: 18px; font-weight: 700; color: #e94560; }
  .nav-item { display: flex; align-items: center; padding: 10px 20px; color: #aaa; text-decoration: none; font-size: 14px; transition: all 0.2s; }
  .nav-item:hover, .nav-item.active { background: #e9456015; color: #e94560; border-right: 3px solid #e94560; }
  .nav-item .icon { margin-right: 10px; }
  .nav-label { padding: 8px 20px; font-size: 10px; color: #555; text-transform: uppercase; letter-spacing: 1px; }
  .sidebar-footer { margin-top: auto; padding: 15px 20px; border-top: 1px solid #2a2a4a; font-size: 12px; color: #666; }
  .main { margin-left: 240px; padding: 25px; }
  .topbar { display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px; }
  .topbar h1 { font-size: 22px; color: #fff; }
  .card { background: #1a1a2e; border: 1px solid #2a2a4a; border-radius: 12px; padding: 20px; margin-bottom: 20px; }
  .card-title { font-size: 15px; font-weight: 600; color: #fff; margin-bottom: 16px; padding-bottom: 12px; border-bottom: 1px solid #2a2a4a; }
  .summary { display: grid; grid-template-columns: 1fr 1fr; gap: 16px; margin-bottom: 20px; }
  .sum-card { background: #1a1a2e; border: 1px solid #2a2a4a; border-radius: 10px; padding: 18px; }
  .sum-card .val { font-size: 26px; font-weight: 700; color: #e94560; }
  .sum-card .lbl { font-size: 12px; color: #888; margin-top: 4px; }
  table { width: 100%; border-collapse: collapse; font-size: 13px; }
  th { padding: 10px 12px; text-align: left; color: #888; border-bottom: 1px solid #2a2a4a; }
  td { padding: 10px 12px; border-bottom: 1px solid #1e1e38; color: #ccc; }
  tr:hover td { background: #ffffff05; }
  .badge { padding: 3px 10px; border-radius: 12px; font-size: 11px; font-weight: 500; }
  .badge-tunai    { background: #06d6a020; color: #06d6a0; }
  .badge-transfer { background: #3a86ff20; color: #3a86ff; }
  .badge-saldo    { background: #9b5de520; color: #9b5de5; }
</style>
</head>
<body>
<div class="sidebar">
  <div class="sidebar-logo">🖥️ Rental Warnet</div>
  <div class="nav-label">Menu Utama</div>
  <a href="dashboard.php" class="nav-item"><span class="icon">📊</span>Dashboard</a>
  <a href="pelanggan.php" class="nav-item"><span class="icon">👥</span>Pelanggan</a>
  <a href="komputer.php"  class="nav-item"><span class="icon">💻</span>Komputer</a>
  <a href="transaksi.php" class="nav-item active"><span class="icon">💳</span>Transaksi</a>
  <a href="sesi.php"      class="nav-item"><span class="icon">⏱️</span>Sesi Aktif</a>
  <?php if ($_SESSION['role'] === 'admin'): ?>
  <div class="nav-label">Admin</div>
  <a href="users.php"  class="nav-item"><span class="icon">🔐</span>Manajemen User</a>
  <a href="backup.php" class="nav-item"><span class="icon">💾</span>Backup & Restore</a>
  <?php endif; ?>
  <div class="sidebar-footer">
    <?= ucfirst($_SESSION['role']) ?> &nbsp;|&nbsp; <a href="logout.php" style="color:#e94560;text-decoration:none">Logout</a>
  </div>
</div>
<div class="main">
  <div class="topbar"><h1>💳 Data Transaksi</h1></div>

  <div class="summary">
    <div class="sum-card">
      <div class="val">Rp <?= number_format($total['t'], 0, ',', '.') ?></div>
      <div class="lbl">Total Pendapatan</div>
    </div>
    <div class="sum-card">
      <div class="val"><?= $total['n'] ?></div>
      <div class="lbl">Jumlah Transaksi</div>
    </div>
  </div>

  <div class="card">
    <div class="card-title">📋 Riwayat Transaksi</div>
    <table>
      <tr><th>#</th><th>Pelanggan</th><th>PC</th><th>Paket</th><th>Mulai</th><th>Selesai</th><th>Total</th><th>Metode</th><th>Kasir</th></tr>
      <?php while ($row = $data->fetch_assoc()): ?>
      <tr>
        <td><?= $row['transaksi_id'] ?></td>
        <td><?= htmlspecialchars($row['pelanggan']) ?></td>
        <td><?= $row['nomor_unit'] ?></td>
        <td><?= htmlspecialchars($row['nama_paket']) ?></td>
        <td><?= date('d/m H:i', strtotime($row['waktu_mulai'])) ?></td>
        <td><?= $row['waktu_selesai'] ? date('d/m H:i', strtotime($row['waktu_selesai'])) : '-' ?></td>
        <td><b>Rp <?= number_format($row['total_bayar'], 0, ',', '.') ?></b></td>
        <td><span class="badge badge-<?= $row['metode_bayar'] ?>"><?= $row['metode_bayar'] ?></span></td>
        <td><?= $row['kasir'] ?></td>
      </tr>
      <?php endwhile; ?>
    </table>
  </div>
</div>
</body>
</html>
