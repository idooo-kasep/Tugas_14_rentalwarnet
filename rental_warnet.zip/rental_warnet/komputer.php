<?php
session_start();
if (!isset($_SESSION['user_id'])) { header('Location: login.php'); exit; }
require_once 'koneksi.php';

$msg = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['aksi'])) {
    if ($_POST['aksi'] === 'tambah') {
        $unit = trim($_POST['nomor_unit']);
        $spec = trim($_POST['spesifikasi']);
        $status = $_POST['status'];
        $lokasi = trim($_POST['lokasi']);
        $stmt = $conn->prepare("INSERT INTO komputer (nomor_unit, spesifikasi, status, lokasi) VALUES (?,?,?,?)");
        $stmt->bind_param('ssss', $unit, $spec, $status, $lokasi);
        if ($stmt->execute()) $msg = '<div class="alert-ok">✅ Komputer berhasil ditambahkan!</div>';
        else $msg = '<div class="alert-err">❌ Gagal: ' . $conn->error . '</div>';
    } elseif ($_POST['aksi'] === 'ubah_status') {
        $id = intval($_POST['id']);
        $status = $_POST['status'];
        $conn->query("UPDATE komputer SET status='$status' WHERE komputer_id=$id");
        $msg = '<div class="alert-ok">✅ Status diperbarui.</div>';
    } elseif ($_POST['aksi'] === 'hapus') {
        $id = intval($_POST['id']);
        $conn->query("DELETE FROM komputer WHERE komputer_id=$id");
        $msg = '<div class="alert-ok">✅ Komputer dihapus.</div>';
    }
}

$data = $conn->query("SELECT * FROM komputer ORDER BY nomor_unit");
$status_count = $conn->query("SELECT status, COUNT(*) n FROM komputer GROUP BY status");
$sc = [];
while ($r = $status_count->fetch_assoc()) $sc[$r['status']] = $r['n'];
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<title>Komputer - Rental Warnet</title>
<style>
  * { box-sizing: border-box; margin: 0; padding: 0; }
  body { font-family: 'Segoe UI', sans-serif; background: #0f0f23; color: #e0e0e0; }
  .sidebar { position: fixed; top: 0; left: 0; width: 240px; height: 100vh; background: #1a1a2e; border-right: 1px solid #2a2a4a; display: flex; flex-direction: column; }
  .sidebar-logo { padding: 20px; border-bottom: 1px solid #2a2a4a; font-size: 18px; font-weight: 700; color: #e94560; }
  .nav-item { display: flex; align-items: center; padding: 10px 20px; color: #aaa; text-decoration: none; font-size: 14px; transition: all 0.2s; }
  .nav-item:hover, .nav-item.active { background: #e9456015; color: #e94560; border-right: 3px solid #e94560; }
  .nav-item .icon { margin-right: 10px; }
  .nav-label { padding: 8px 20px; font-size: 10px; color: #555; text-transform: uppercase; letter-spacing: 1px; }
  .sidebar-footer { margin-top: auto; padding: 15px 20px; border-top: 1px solid #2a2a4a; font-size: 12px; color: #666; }
  .main { margin-left: 240px; padding: 25px; }
  .topbar { display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px; }
  .topbar h1 { font-size: 22px; color: #fff; }
  .card { background: #1a1a2e; border: 1px solid #2a2a4a; border-radius: 12px; padding: 20px; margin-bottom: 20px; }
  .card-title { font-size: 15px; font-weight: 600; color: #fff; margin-bottom: 16px; padding-bottom: 12px; border-bottom: 1px solid #2a2a4a; }
  .stats-mini { display: grid; grid-template-columns: repeat(3,1fr); gap: 12px; margin-bottom: 20px; }
  .sm-card { background: #1a1a2e; border: 1px solid #2a2a4a; border-radius: 10px; padding: 15px; text-align: center; }
  .sm-card .val { font-size: 28px; font-weight: 700; }
  .sm-card .lbl { font-size: 12px; color: #888; margin-top: 4px; }
  .green { color: #06d6a0; } .orange { color: #ffd166; } .red { color: #e94560; }
  table { width: 100%; border-collapse: collapse; font-size: 13px; }
  th { padding: 10px 12px; text-align: left; color: #888; border-bottom: 1px solid #2a2a4a; }
  td { padding: 10px 12px; border-bottom: 1px solid #1e1e38; color: #ccc; }
  tr:hover td { background: #ffffff05; }
  .badge { padding: 3px 10px; border-radius: 12px; font-size: 11px; font-weight: 500; }
  .badge-tersedia  { background: #06d6a020; color: #06d6a0; }
  .badge-digunakan { background: #ffd16620; color: #ffd166; }
  .badge-rusak     { background: #e9456020; color: #e94560; }
  .form-row { display: grid; grid-template-columns: repeat(4,1fr); gap: 12px; margin-bottom: 12px; }
  .form-group label { display: block; font-size: 12px; color: #888; margin-bottom: 5px; }
  .form-group input, .form-group select { width: 100%; padding: 10px; background: #0f0f23; border: 1px solid #2a2a4a; border-radius: 8px; color: #fff; font-size: 13px; }
  .form-group input:focus, .form-group select:focus { outline: none; border-color: #e94560; }
  .btn { padding: 8px 16px; border-radius: 8px; font-size: 12px; font-weight: 500; cursor: pointer; border: none; }
  .btn-primary { background: #e94560; color: #fff; padding: 10px 20px; font-size: 13px; }
  .btn-sm { padding: 4px 10px; font-size: 11px; }
  .btn-green  { background: #06d6a0; color: #000; }
  .btn-yellow { background: #ffd166; color: #000; }
  .btn-red    { background: #e94560; color: #fff; }
  .btn:hover { opacity: 0.85; }
  .alert-ok  { background: #06d6a020; border: 1px solid #06d6a0; color: #06d6a0; padding: 10px 15px; border-radius: 8px; margin-bottom: 15px; }
  .alert-err { background: #e9456020; border: 1px solid #e94560; color: #e94560; padding: 10px 15px; border-radius: 8px; margin-bottom: 15px; }
</style>
</head>
<body>
<div class="sidebar">
  <div class="sidebar-logo">🖥️ Rental Warnet</div>
  <div class="nav-label">Menu Utama</div>
  <a href="dashboard.php" class="nav-item"><span class="icon">📊</span>Dashboard</a>
  <a href="pelanggan.php" class="nav-item"><span class="icon">👥</span>Pelanggan</a>
  <a href="komputer.php"  class="nav-item active"><span class="icon">💻</span>Komputer</a>
  <a href="transaksi.php" class="nav-item"><span class="icon">💳</span>Transaksi</a>
  <a href="sesi.php"      class="nav-item"><span class="icon">⏱️</span>Sesi Aktif</a>
  <?php if ($_SESSION['role'] === 'admin'): ?>
  <div class="nav-label">Admin</div>
  <a href="users.php"  class="nav-item"><span class="icon">🔐</span>Manajemen User</a>
  <a href="backup.php" class="nav-item"><span class="icon">💾</span>Backup & Restore</a>
  <?php endif; ?>
  <div class="sidebar-footer">
    <?= ucfirst($_SESSION['role']) ?> &nbsp;|&nbsp; <a href="logout.php" style="color:#e94560;text-decoration:none">Logout</a>
  </div>
</div>
<div class="main">
  <div class="topbar"><h1>💻 Data Komputer</h1></div>
  <?= $msg ?>

  <div class="stats-mini">
    <div class="sm-card"><div class="val green"><?= $sc['tersedia'] ?? 0 ?></div><div class="lbl">Tersedia</div></div>
    <div class="sm-card"><div class="val orange"><?= $sc['digunakan'] ?? 0 ?></div><div class="lbl">Digunakan</div></div>
    <div class="sm-card"><div class="val red"><?= $sc['rusak'] ?? 0 ?></div><div class="lbl">Rusak</div></div>
  </div>

  <div class="card">
    <div class="card-title">➕ Tambah Komputer</div>
    <form method="POST">
      <input type="hidden" name="aksi" value="tambah">
      <div class="form-row">
        <div class="form-group"><label>Nomor Unit *</label><input name="nomor_unit" required placeholder="PC-06"></div>
        <div class="form-group"><label>Status</label>
          <select name="status">
            <option value="tersedia">Tersedia</option>
            <option value="digunakan">Digunakan</option>
            <option value="rusak">Rusak</option>
          </select>
        </div>
        <div class="form-group"><label>Lokasi</label><input name="lokasi" placeholder="Zona Gaming"></div>
        <div class="form-group" style="display:flex;align-items:flex-end"><button type="submit" class="btn btn-primary">➕ Tambah</button></div>
      </div>
      <div class="form-row" style="grid-template-columns:1fr">
        <div class="form-group"><label>Spesifikasi</label><input name="spesifikasi" placeholder="Intel i5, RAM 16GB, ..."></div>
      </div>
    </form>
  </div>

  <div class="card">
    <div class="card-title">📋 Daftar Komputer</div>
    <table>
      <tr><th>ID</th><th>No. Unit</th><th>Spesifikasi</th><th>Status</th><th>Lokasi</th><th>Ubah Status</th><th>Hapus</th></tr>
      <?php while ($row = $data->fetch_assoc()): ?>
      <tr>
        <td><?= $row['komputer_id'] ?></td>
        <td><b><?= $row['nomor_unit'] ?></b></td>
        <td><?= htmlspecialchars($row['spesifikasi'] ?? '-') ?></td>
        <td><span class="badge badge-<?= $row['status'] ?>"><?= $row['status'] ?></span></td>
        <td><?= $row['lokasi'] ?? '-' ?></td>
        <td>
          <form method="POST" style="display:flex;gap:4px">
            <input type="hidden" name="aksi" value="ubah_status">
            <input type="hidden" name="id" value="<?= $row['komputer_id'] ?>">
            <select name="status" style="background:#0f0f23;color:#ccc;border:1px solid #2a2a4a;border-radius:6px;padding:4px;font-size:11px">
              <option <?= $row['status']=='tersedia'?'selected':'' ?>>tersedia</option>
              <option <?= $row['status']=='digunakan'?'selected':'' ?>>digunakan</option>
              <option <?= $row['status']=='rusak'?'selected':'' ?>>rusak</option>
            </select>
            <button type="submit" class="btn btn-sm btn-green">✓</button>
          </form>
        </td>
        <td>
          <form method="POST" onsubmit="return confirm('Hapus?')" style="display:inline">
            <input type="hidden" name="aksi" value="hapus">
            <input type="hidden" name="id" value="<?= $row['komputer_id'] ?>">
            <button type="submit" class="btn btn-sm btn-red">🗑</button>
          </form>
        </td>
      </tr>
      <?php endwhile; ?>
    </table>
  </div>
</div>
</body>
</html>
